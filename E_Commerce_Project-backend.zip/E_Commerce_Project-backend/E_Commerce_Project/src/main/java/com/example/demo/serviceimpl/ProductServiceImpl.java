package com.example.demo.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Product;
import com.example.demo.model.ProductCategory;
import com.example.demo.repository.ProductCategoryRepository;
import com.example.demo.repository.ProductRepository;
import com.example.demo.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private ProductCategoryRepository categoryRepo;

	@Override
	public Product saveProduct(Product product) {
		// TODO Auto-generated method stub
		Long catId = product.getCategory().getId();

	    ProductCategory category = categoryRepo.findById(catId)
	            .orElseThrow(() -> new RuntimeException("Invalid category id: " + catId));

	    product.setCategory(category); // Attach managed entity

	    return productRepository.save(product);
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
	}

	@Override
	public Product getProductById(long proId) {
		// TODO Auto-generated method stub
		return productRepository.findById(proId)
        .orElseThrow(() -> new RuntimeException("Product not found with ID: " + proId));
}


	@Override
	public Product updateProductById(long proId, Product newproduct) {
		// TODO Auto-generated method stub
		Product eProduct = productRepository.findById(proId)
	            .orElseThrow(() -> new RuntimeException("Product not found with ID: " + proId));

	    // Update fields
	    eProduct.setPname(newproduct.getPname());
	    eProduct.setBrand(newproduct.getBrand());
	    eProduct.setDescription(newproduct.getDescription());
	    eProduct.setUnitPrice(newproduct.getUnitPrice());
	    eProduct.setImageUrl(newproduct.getImageUrl());
	    eProduct.setUnitsInStock(newproduct.getUnitsInStock());

	    if (newproduct.getCategory() != null) {
	        Long catId = newproduct.getCategory().getId();

	        ProductCategory category = categoryRepo.findById(catId)
	                .orElseThrow(() -> new RuntimeException("Invalid category id: " + catId));

	        eProduct.setCategory(category);
	    }

	    return productRepository.save(eProduct);
	}

	@Override
	public void deleteProductByProductId(long proId) {
		// TODO Auto-generated method stub
		Product eProduct = productRepository.findById(proId)
	            .orElseThrow(() -> new RuntimeException("Product not found with ID: " + proId));

	    productRepository.delete(eProduct);
		
	}

}
