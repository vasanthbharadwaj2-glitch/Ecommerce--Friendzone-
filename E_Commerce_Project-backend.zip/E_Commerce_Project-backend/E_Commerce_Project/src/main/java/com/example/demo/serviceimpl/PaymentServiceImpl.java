package com.example.demo.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Customer;
import com.example.demo.model.Order;
import com.example.demo.model.Payment;
import com.example.demo.repository.CustomerRepository;
import com.example.demo.repository.OrderRepository;
import com.example.demo.repository.PaymentRepository;
import com.example.demo.service.PaymentService;

@Service
public class PaymentServiceImpl implements PaymentService {
	
	@Autowired
	private PaymentRepository paymentRepo;
	
	@Autowired
    private OrderRepository orderRepo;

    @Autowired
    private CustomerRepository customerRepo;

	@Override
	public Payment savePayment(Payment payment) {
		// TODO Auto-generated method stub
		Long orderId = payment.getOrder().getOrderId();
        Order order = orderRepo.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Invalid Order ID: " + orderId));

        Long custId = payment.getCustomer().getCid();
        Customer customer = customerRepo.findById(custId)
                .orElseThrow(() -> new RuntimeException("Invalid Customer ID: " + custId));

        payment.setOrder(order);
        payment.setCustomer(customer);

        return paymentRepo.save(payment);
	}

	@Override
	public List<Payment> getAllPayments() {
		// TODO Auto-generated method stub
	        return paymentRepo.findAll();

	}

	@Override
	public Payment getPaymentById(long paymentId) {
		// TODO Auto-generated method stub
		return paymentRepo.findById(paymentId)
		        .orElseThrow(() -> new RuntimeException("Payment not found"));
	}

	@Override
	public Payment updatePaymentById(long paymentId, Payment payment) {
		// TODO Auto-generated method stub
		Payment existing = paymentRepo.findById(paymentId)
                .orElseThrow(() -> new RuntimeException("Payment not found with ID: " + paymentId));

        // Update paymentStatus only (order/customer usually do not change)
        existing.setPaymentStatus(payment.getPaymentStatus());

        return paymentRepo.save(existing);
	}

	@Override
	public void deletePaymentByPaymentId(long paymentId) {
		// TODO Auto-generated method stub
		return;
	}

}
