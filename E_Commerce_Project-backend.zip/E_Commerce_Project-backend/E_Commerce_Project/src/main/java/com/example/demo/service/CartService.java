package com.example.demo.service;

import java.util.List;

import com.example.demo.model.CartItem;

public interface CartService {
	
	CartItem addToCart(long customerId, long productId);
    List<CartItem> getCartItems(long customerId);
    void removeFromCart(long cartItemId);
    void clearCart(long customerId);

}
