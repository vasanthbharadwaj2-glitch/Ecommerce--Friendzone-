// PasswordUpdateRequest.java
package com.example.demo.model;

public class PasswordUpdateRequest {
    private String newPassword;

    public String getNewPassword() {
        return newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }
}
