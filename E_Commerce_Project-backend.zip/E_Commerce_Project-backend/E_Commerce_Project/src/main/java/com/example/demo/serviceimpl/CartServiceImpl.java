package com.example.demo.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.CartItem;
import com.example.demo.model.Customer;
import com.example.demo.model.Product;
import com.example.demo.repository.CartRepository;
import com.example.demo.repository.CustomerRepository;
import com.example.demo.repository.ProductRepository;
import com.example.demo.service.CartService;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class CartServiceImpl implements CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private ProductRepository productRepository;

    @Override
    public CartItem addToCart(long customerId, long productId) {

        // ✅ Fetch customer from DB
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        // ✅ Fetch product from DB
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found"));

        // ✅ Check if product already exists in cart
        CartItem existingItem =
                cartRepository.findByCustomer_CidAndProductPid(customerId, productId);

        if (existingItem != null) {
            existingItem.setQuantity(existingItem.getQuantity() + 1);
            return cartRepository.save(existingItem);
        }

        // ✅ Create new cart item
        CartItem cartItem = new CartItem(customer, product, 1);
        return cartRepository.save(cartItem);
    }

    @Override
    public List<CartItem> getCartItems(long customerId) {
        return cartRepository.findByCustomer_Cid(customerId);
    }

    @Override
    public void removeFromCart(long cartItemId) {
        cartRepository.deleteById(cartItemId);
    }

    @Override
    public void clearCart(long customerId) {
        cartRepository.deleteByCustomer_Cid(customerId);
    }
}
