package com.example.demo.model;


import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.hibernate.validator.constraints.URL;

import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "product")

public class Product {

    @Id
    @GeneratedValue(generator="my_seq2")
    @SequenceGenerator(name="my_seq2",sequenceName="MY_SEQ2", allocationSize=1,initialValue=1)
    @Column(name = "id")
    private Long pid;


    @ManyToOne
    @JoinColumn(name = "category_id", nullable = false)
    private ProductCategory category;

    @NotBlank(message = "Name is required.")
    @Column(name = "pname", length=50)
    private String pname;

    @NotBlank(message = "Brand name is required.")
    @Column(name = "pbrand", length = 40)
    private String brand;

    @Column(name = "description",length=300)
    private String description;

    @Positive(message = "Price must be greater than 0")
    @Column(name = "unit_price")
    private BigDecimal unitPrice;

    @NotEmpty(message = "Image URL is required.")
    @URL(message = "Must be a valid URL.")
    @Size(max = 2048, message = "URL is too long.")
    @Column(name = "image_url")
    private String imageUrl;

    @Min(value = 1, message = "At least 1 item should be in stock")
    @Column(name = "units_in_stock")
    private int unitsInStock;

    @Column(name = "prod_add_date")
    @CreationTimestamp
    private Date dateAdded;

    @Column(name = "last_updated")
    @UpdateTimestamp
    private Date lastUpdated;

	public ProductCategory getCategory() {
		return category;
	}

	public void setCategory(ProductCategory category) {
		this.category = category;
		
	}

	public Long getPid() {
		return pid;
	}

	public void setPid(Long pid) {
		this.pid = pid;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public BigDecimal getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(BigDecimal unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public int getUnitsInStock() {
		return unitsInStock;
	}

	public void setUnitsInStock(int unitsInStock) {
		this.unitsInStock = unitsInStock;
	}

	public Date getDateAdded() {
		return dateAdded;
	}

	public void setDateAdded(Date dateAdded) {
		this.dateAdded = dateAdded;
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}

	public void setLastUpdated(Date lastUpdated) {
		this.lastUpdated = lastUpdated;
	}

	@Override
	public String toString() {
		return "Product [pid=" + pid + ", category=" + category + ", pname=" + pname + ", brand=" + brand
				+ ", description=" + description + ", unitPrice=" + unitPrice + ", imageUrl=" + imageUrl
				+ ", unitsInStock=" + unitsInStock + ", dateAdded=" + dateAdded + ", lastUpdated=" + lastUpdated + "]";
	}

	
	
    
}