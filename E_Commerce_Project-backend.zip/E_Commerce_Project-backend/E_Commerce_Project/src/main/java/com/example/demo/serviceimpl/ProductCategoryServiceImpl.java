package com.example.demo.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Order;
import com.example.demo.model.ProductCategory;
import com.example.demo.repository.OrderRepository;
import com.example.demo.repository.ProductCategoryRepository;
import com.example.demo.service.ProductCategoryService;

@Service
public class ProductCategoryServiceImpl implements ProductCategoryService {

	@Autowired
	private ProductCategoryRepository productCategoryRepository;
	
	@Override
	public ProductCategory saveCategory(ProductCategory productCategory) {
		// TODO Auto-generated method stub
		return productCategoryRepository.save(productCategory);
	}

	@Override
	public List<ProductCategory> getAllCategories() {
		// TODO Auto-generated method stub
		return productCategoryRepository.findAll();
	}

	@Override
	public ProductCategory getCategoryById(long pcId) {
		// TODO Auto-generated method stub
		Optional<ProductCategory> optionalProductCategory = productCategoryRepository.findById(pcId);
		if(!optionalProductCategory.isPresent()) {
			throw new ResourceNotFoundException("ProductCategory", "productCategoryId", pcId);
		}
		return optionalProductCategory.get();
	}

	@Override
	public ProductCategory updateCategoryByCategoryId(long pcId, ProductCategory newproductCategory) {
		// TODO Auto-generated method stub
		ProductCategory eproductCategory  = getCategoryById(pcId);
		eproductCategory.setCategoryName(newproductCategory.getCategoryName());
		return productCategoryRepository.save(eproductCategory);
	}

	@Override
	public void deleteCategoryByCategoryId(long pcId) {
		// TODO Auto-generated method stub
		ProductCategory eproductCategory = getCategoryById(pcId);
		productCategoryRepository.delete(eproductCategory);	
		
	}

}
