package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Payment;

public interface PaymentService {
	
	public Payment savePayment(Payment payment);
	public List<Payment> getAllPayments();
	public Payment getPaymentById(long paymentId);
	public Payment updatePaymentById(long paymentId, Payment payment);
	public void deletePaymentByPaymentId (long paymentId);

}
