package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.CartItem;
import com.example.demo.service.CartService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/cart/api")
public class CartController {
	
	@Autowired
    private CartService cartService;

    @PostMapping("/add/{customerId}/{productId}")
    public CartItem addToCart(@PathVariable long customerId, @PathVariable long productId) {
        return cartService.addToCart(customerId, productId);
    }

    @GetMapping("/{customerId}")
    public List<CartItem> getCart(@PathVariable long customerId) {
        return cartService.getCartItems(customerId);
    }

    @DeleteMapping("/remove/{cartItemId}")
    public void removeFromCart(@PathVariable long cartItemId) {
        cartService.removeFromCart(cartItemId);
    }

    @DeleteMapping("/clear/{customerId}")
    public void clearCart(@PathVariable long customerId) {
        cartService.clearCart(customerId);
    }

}
