package com.example.demo.exception;

public class ResourceNotFoundException extends RuntimeException{ 
	
		public ResourceNotFoundException(String resourceName, String fieldName, long custId )
		{
		super(resourceName+" "+fieldName+" "+custId);
		System.out.println("con");
		}
}