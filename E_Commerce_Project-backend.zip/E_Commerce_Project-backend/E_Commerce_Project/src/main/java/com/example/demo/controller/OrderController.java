package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Customer;
import com.example.demo.model.Order;
import com.example.demo.model.PaymentConfirmationRequest;
import com.example.demo.service.CustomerService;
import com.example.demo.service.OrderService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/order/api")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private CustomerService customerService;

    // ---------------- CREATE ORDER (manual / unused) ----------------
    @PostMapping("/{customerId}")
    public ResponseEntity<Order> createOrder(
            @PathVariable long customerId,
            @RequestBody Order order) {

        Customer customer = customerService.getCustomerById(customerId);
        order.setCustomer(customer);

        Order saved = orderService.saveOrder(order);
        return new ResponseEntity<>(saved, HttpStatus.CREATED);
    }

    // ---------------- GET ALL ORDERS ----------------
    @GetMapping
    public List<Order> getAllOrders() {
        return orderService.getAllOrders();
    }

    // ---------------- GET ORDERS BY CUSTOMER ----------------
    @GetMapping("/customer/{customerId}")
    public List<Order> getOrdersByCustomer(@PathVariable long customerId) {
        return orderService.getOrdersByCustomer(customerId);
    }

    // ---------------- GET ORDER BY ID ----------------
    @GetMapping("/{orderId}")
    public Order getOrderById(@PathVariable long orderId) {
        return orderService.getOrderById(orderId);
    }

    // ---------------- UPDATE ORDER ----------------
    @PutMapping("/{orderId}")
    public Order updateOrder(
            @PathVariable long orderId,
            @RequestBody Order order) {
        return orderService.updateOrderByOrderId(orderId, order);
    }

    // ---------------- DELETE ORDER ----------------
    @DeleteMapping("/{orderId}")
    public String deleteOrder(@PathVariable long orderId) {
        orderService.deleteOrderByOrderId(orderId);
        return "Order deleted: " + orderId;
    }

    // ---------------- AFTER PAYMENT (USED BY RAZORPAY) ----------------
    @PostMapping("/after-payment/{customerId}")
    public ResponseEntity<Order> saveOrderAfterPayment(
            @PathVariable long customerId,
            @RequestParam String razorpayOrderId,
            @RequestParam String razorpayPaymentId) {
    	System.out.println("afterpaymentcontroller");
        Order order = orderService.createOrderAfterPayment(
                customerId,
                razorpayOrderId,
                razorpayPaymentId
        );

        return ResponseEntity.ok(order);
    }
}
