package com.example.demo.service;

import java.util.List;

import com.example.demo.model.ProductCategory;

public interface ProductCategoryService {
	
	public ProductCategory saveCategory(ProductCategory productCategory);
	public List<ProductCategory> getAllCategories();
	public ProductCategory getCategoryById(long pcId);
	public ProductCategory updateCategoryByCategoryId(long pcId, ProductCategory productCategory);
	public void deleteCategoryByCategoryId (long pcId);


}
