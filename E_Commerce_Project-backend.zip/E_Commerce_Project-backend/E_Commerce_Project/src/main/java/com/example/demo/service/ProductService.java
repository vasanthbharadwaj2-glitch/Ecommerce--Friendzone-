package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Product;

public interface ProductService {
	
	public Product saveProduct(Product product);
	public List<Product> getAllProducts();
	public Product getProductById(long proId);
	public Product updateProductById(long proId, Product product);
	public void deleteProductByProductId (long proId);


}
