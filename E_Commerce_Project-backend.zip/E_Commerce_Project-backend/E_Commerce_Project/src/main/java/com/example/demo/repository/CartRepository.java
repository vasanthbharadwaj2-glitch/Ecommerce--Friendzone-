package com.example.demo.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.CartItem;
public interface CartRepository extends JpaRepository<CartItem, Long> {
	
	List<CartItem> findByCustomer_Cid(long customerId);

    CartItem findByCustomer_CidAndProductPid(long customerId, long productId);

    void deleteByCustomer_Cid(long Cid);

}
