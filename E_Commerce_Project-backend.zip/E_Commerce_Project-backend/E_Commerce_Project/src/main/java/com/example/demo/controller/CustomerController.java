package com.example.demo.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Customer;
import com.example.demo.model.PasswordUpdateRequest;
import com.example.demo.service.CustomerService;

import jakarta.validation.Valid;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/customer/api")
public class CustomerController {
	@Autowired
	private CustomerService customerServiceInterface;
	
	@PostMapping
	public ResponseEntity<Customer> saveCustomer(@Valid @RequestBody Customer customer){
		
		Customer customer1 = customerServiceInterface.saveCustomer(customer);
		return new ResponseEntity(customer1, HttpStatus.CREATED );
	}
	
	@GetMapping
	public List<Customer> getAllCustomers()
	{
		return customerServiceInterface.getAllCustomers();
	}
	
	@GetMapping("{custId}")
	public Customer getCustomerById(@PathVariable("custId") long custId)
	{
		return customerServiceInterface.getCustomerById(custId);
	}
	
	@PutMapping("{custId}")
	public Customer updateCustomerByCustId(@PathVariable("custId") long custId, @RequestBody Customer customer)
	{
		return customerServiceInterface.updateCustomerByCustId(custId, customer);
	}
	
	@DeleteMapping("{custId}")
	public String deleteCustById(@PathVariable("custId") long custId)
	{
		customerServiceInterface.deleteCustById(custId);
		return "Customer deleted successfully  "+custId;
	}
	
	@PostMapping("/register")
	public ResponseEntity<Customer> registerUser(@Valid @RequestBody Customer customer)
	{
		Customer customer1= customerServiceInterface.registerUser(customer);
		return new ResponseEntity<Customer>(customer1,HttpStatus.CREATED);
	}

	@PostMapping("/login")
	public ResponseEntity<Customer> loginUser(@RequestBody Customer customer)
	{
		Customer customer1= customerServiceInterface.loginUser(customer);
		return new ResponseEntity<Customer>(customer1,HttpStatus.CREATED);
	}
	
	@GetMapping("/by-email")
	public Optional<Customer> getByEmail(@RequestParam String email) {
	    return customerServiceInterface.getByEmail(email);
	}
	@GetMapping("/profile/{id}")
	public ResponseEntity<Customer> getProfile(@PathVariable long id) {
	    Customer customer = customerServiceInterface.getCustomerProfile(id);

	    if (customer == null) {
	        return ResponseEntity.notFound().build();
	    }
	    return ResponseEntity.ok(customer);
	}
	
	@PutMapping("/update-password")
	public ResponseEntity<?> updatePassword(
	        @RequestParam String email,
	        @RequestBody PasswordUpdateRequest request) {

	    customerServiceInterface.updatePasswordByEmail(email, request.getNewPassword());
	    return ResponseEntity.ok().build(); // 🔥 VERY IMPORTANT
	}

	

}
