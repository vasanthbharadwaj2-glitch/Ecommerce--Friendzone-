package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import com.example.demo.model.Customer;

public interface CustomerService {
	public Customer saveCustomer(Customer customer);
	public List<Customer> getAllCustomers();
	public Customer getCustomerById(long custId);
	public Customer updateCustomerByCustId(long custId, Customer customer);
	public void deleteCustById (long custId);
	public Customer registerUser(Customer customer);
	public Customer loginUser(Customer customer);
	public Optional<Customer> getByEmail(String email);
	public Customer getCustomerProfile(long custId);
	void updatePasswordByEmail(String email, String newPassword);
	Customer getCustomerByEmail(String email);

	
	

}
