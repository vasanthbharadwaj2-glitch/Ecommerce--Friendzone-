package com.example.demo.serviceimpl;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.CartItem;
import com.example.demo.model.Customer;
import com.example.demo.model.Order;
import com.example.demo.model.OrderItem;
import com.example.demo.repository.CartRepository;
import com.example.demo.repository.CustomerRepository;
import com.example.demo.repository.OrderRepository;
import com.example.demo.service.OrderService;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepo;

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private CartRepository cartRepository;

    // ===================== ORDERS BY CUSTOMER =====================
    @Override
    public List<Order> getOrdersByCustomer(Long customerId) {
        return orderRepo.findByCustomer_Cid(customerId);
    }

    // ===================== PAYMENT → ORDER =====================
    @Override
    public Order createOrderAfterPayment(
            long customerId,
            String razorpayOrderId,
            String razorpayPaymentId) {

        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Customer not found"));
        System.out.println("finding customer by id");

        List<CartItem> cartItems = cartRepository.findByCustomer_Cid(customerId);
        System.out.println("Retriveing cart items by customer id");
        

        // 🔍 debug (does NOT affect logic)
        System.out.println("Cart size before order = " + cartItems.size());

        if (cartItems.isEmpty()) {
            throw new RuntimeException("Cart empty");
        }

        Order order = new Order();
        order.setCustomer(customer);
        order.setOrderDate(LocalDateTime.now());
        order.setRazorpayOrderId(razorpayOrderId);
        order.setRazorpayPaymentId(razorpayPaymentId);

        // REQUIRED FIELDS (already working – kept as-is)
        order.setOrderTrackingNumber("ORD-" + System.currentTimeMillis());
        order.setStatus("PAID");

        double total = 0;
        int totalQty = 0;
        List<OrderItem> items = new ArrayList<>();

        for (CartItem cart : cartItems) {
            OrderItem item = new OrderItem();
            item.setOrder(order);
            item.setProduct(cart.getProduct());
            item.setQuantity(cart.getQuantity());
            item.setPrice(cart.getProduct().getUnitPrice());

            total += cart.getQuantity()
                    * cart.getProduct().getUnitPrice().doubleValue();

            totalQty += cart.getQuantity();
            items.add(item);
        }

        order.setTotalAmount(total);
        order.setTotalQuantity(totalQty);
        order.setOrderItems(items);

        Order savedOrder = orderRepo.save(order);
        System.out.println("order saved");
        

        // clear cart AFTER order is saved (existing behaviour)
       // cartRepository.deleteByCustomer_Cid(customerId);
        System.out.println("Delete cart based on customer id");

        return savedOrder;
    }

    // ===================== UNUSED CRUD (KEPT INTACT) =====================
    @Override
    public Order saveOrder(Order o) {
        return orderRepo.save(o);
    }

    @Override
    public List<Order> getAllOrders() {
        return orderRepo.findAll();
    }

    @Override
    public Order getOrderById(Long id) {
        return orderRepo.findById(id).orElse(null);
    }

    @Override
    public Order updateOrderByOrderId(Long id, Order o) {
        return orderRepo.save(o);
    }

    @Override
    public void deleteOrderByOrderId(Long id) {
        orderRepo.deleteById(id);
    }
}
