package com.example.demo.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "customer_table")
public class Customer {

    @OneToOne(mappedBy = "customer")
    @JsonIgnore 
    private Payment payment;

    @Id
    @GeneratedValue(generator = "my_seq")
    @SequenceGenerator(name = "my_seq", sequenceName = "MY_SEQ", allocationSize = 1, initialValue = 1000)
    @Column(name = "id")
    private Long cid;

    @NotBlank(message = "Name is required.")
    @Size(min = 2, max = 25, message = "Name must be between 2 to 25 characters")
    @Column(name = "first_name", length = 50)
    private String firstName;

    @Column(name = "last_name", length = 30)
    private String lastName;

    @NotBlank(message = "Email is required")
    @Email(message = "Invalid Email!!")
    @Column(length = 40, unique = true)
    private String email;

    @NotBlank(message = "Username is required")
    @Column(length = 30, unique = true)
    private String userName;

    @NotBlank(message = "Password is required")
    @Size(min = 8, max = 100, message = "Password must be at least 8 characters")
    @Column(nullable = false, length = 200)
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private String password;

    @NotBlank(message = "Role is required")
    @Column(nullable = false, length = 50)
    private String role;

    @NotBlank(message = "Mobile number is required")
    @Pattern(regexp = "^[1-9]\\d{9}$", message = "Mobile number must be exactly 10 digits and cannot start with zero.")
    @Column(name = "mobile_no", unique = true, nullable = false, length = 10)
    private String mobileNo;

    @NotBlank(message = "Address cannot be blank")
    @Column(name = "cust_address", length = 200)
    private String address;


    // -----------------------------------------------------
    // ⭐ REQUIRED CONSTRUCTORS (ADDED — NOTHING MODIFIED)
    // -----------------------------------------------------

    public Customer() {
        // default constructor
    }

    public Customer(Long cid, String firstName, String lastName, String email,
                    String userName, String password, String role,
                    String mobileNo, String address) {

        this.cid = cid;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.userName = userName;
        this.password = password;
        this.role = role;
        this.mobileNo = mobileNo;
        this.address = address;
    }


    // -----------------------------------------------------
    // GETTERS & SETTERS (UNCHANGED)
    // -----------------------------------------------------

    public Long getCid() {
        return cid;
    }

    public void setCid(Long cid) {
        this.cid = cid;  // FIXED – correct assignment
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Payment getPayment() {
        return payment;
    }

    public void setPayment(Payment payment) {
        this.payment = payment;
    }

    @Override
    public String toString() {
        return "Customer [Cid=" + cid +
                ", firstName=" + firstName +
                ", lastName=" + lastName +
                ", email=" + email +
                ", userName=" + userName +
                ", password=" + password +
                ", role=" + role +
                ", mobileNo=" + mobileNo +
                ", address=" + address + "]";
    }
}
