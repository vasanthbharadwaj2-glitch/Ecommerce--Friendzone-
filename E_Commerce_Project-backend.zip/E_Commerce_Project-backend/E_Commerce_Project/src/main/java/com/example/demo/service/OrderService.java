package com.example.demo.service;

import java.util.List;
import com.example.demo.model.Order;

public interface OrderService {

    Order saveOrder(Order order);

    List<Order> getAllOrders();

    Order getOrderById(Long id);

    Order updateOrderByOrderId(Long id, Order order);

    void deleteOrderByOrderId(Long id);

    List<Order> getOrdersByCustomer(Long customerId);  // NEW
    Order createOrderAfterPayment(
    	    long customerId,
    	    String razorpayOrderId,
    	    String razorpayPaymentId
    	);

}
