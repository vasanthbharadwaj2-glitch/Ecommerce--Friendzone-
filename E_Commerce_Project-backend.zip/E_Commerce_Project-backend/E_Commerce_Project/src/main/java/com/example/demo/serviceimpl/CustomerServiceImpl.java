package com.example.demo.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Customer;
import com.example.demo.repository.CustomerRepository;
import com.example.demo.service.CustomerService;


@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	
	private CustomerRepository customerRepository;
	@Autowired
	private EmailService emailService;
	@Override
	public Customer saveCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerRepository.save(customer);
	}
	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return customerRepository.findAll();
	}
	@Override
	public Customer getCustomerById(long custId) {
		// TODO Auto-generated method stub
		Optional<Customer> optionalCustomer = customerRepository.findById(custId);
		if(!optionalCustomer.isPresent()) {
			throw new ResourceNotFoundException("Customer", "customerId", custId);
		}
		return optionalCustomer.get();
	}
	@Override
	public Customer updateCustomerByCustId(long custId, Customer newCustomer) {
		// TODO Auto-generated method stub
		Customer eCustomer  = getCustomerById(custId);// eStudent contains old details
		eCustomer.setFirstName(newCustomer.getFirstName());
		eCustomer.setLastName(newCustomer.getLastName());
		eCustomer.setEmail(newCustomer.getEmail());
		eCustomer.setAddress(newCustomer.getAddress());
		eCustomer.setMobileNo(newCustomer.getMobileNo());
		return customerRepository.save(eCustomer);

	}
	@Override
	public void deleteCustById(long custId) {
		// TODO Auto-generated method stub
		Customer eCustomer = getCustomerById(custId);// checking if student exists
		customerRepository.deleteById(eCustomer.getCid());	
	}
	@Override
	public Customer registerUser(Customer customer) {
		// TODO Auto-generated method stub
		Customer customer1 = customerRepository.save(customer);
		String message = "Hello,\n\nThank you for registering with FriendZone! Your account has been created successfully.\n\nWe’re excited to have you with us. Start exploring the latest products, exclusive deals, and a smooth shopping experience tailored just for you.\n\nWelcome to the FriendZone family!";
		emailService.sendEmail(customer.getEmail(), "Registration Successful!!", message);
		return customer1;
	}
	
	@Override
	public Customer loginUser(Customer customer) {
		// TODO Auto-generated method stub
		return customerRepository.findByEmailAndPassword(customer.getEmail(), customer.getPassword());
	}
	
	@Override
	public Optional<Customer> getByEmail(String email) {
	    return customerRepository.findByEmail(email);
	}
	
	@Override
	public Customer getCustomerByEmail(String email) {
	    return customerRepository.findByEmail(email)
	            .orElse(null);   // behaves exactly like before
	}

	@Override
	public Customer getCustomerProfile(long custId) {
	    return customerRepository.findById(custId)
	            .orElse(null);
	}
	@Override
	public void updatePasswordByEmail(String email, String newPassword) {
		// TODO Auto-generated method stub
		
	}
	
}
