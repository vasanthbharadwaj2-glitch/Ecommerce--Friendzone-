package com.example.demo.controller;

import com.example.demo.model.PaymentRequest;
import com.razorpay.RazorpayClient;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/payment")
@CrossOrigin(origins = "http://localhost:4200")
public class PaymentController {

    private static final String KEY = "rzp_test_Rr6AZ5xurYtSR2";
    private static final String SECRET = "D3qUf1rDL0ZgXFSctYnH9d54";

    @PostMapping("/create-order")
    public String createRazorpayOrder(@RequestBody PaymentRequest request) throws Exception {

        RazorpayClient client = new RazorpayClient(KEY, SECRET);

        JSONObject options = new JSONObject();
        options.put("amount", request.getAmount() * 100);
        options.put("currency", "INR");
        options.put("receipt", "order_rcpt_" + System.currentTimeMillis());

        com.razorpay.Order order = client.orders.create(options);

        return order.toString();
    }
}
