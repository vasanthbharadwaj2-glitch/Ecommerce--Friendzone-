package com.example.demo.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

@Entity
@Table(name = "product_category")

public class ProductCategory {

	@Id
	@GeneratedValue(generator="my_seq3")
	@SequenceGenerator(name="my_seq3",sequenceName="MY_SEQ3", allocationSize=1,initialValue=100)
    @Column(name = "id")
    private Long id;

	@NotBlank(message = "Category name is required.")
    @Column(name = "category_name", length = 50)
    private String categoryName;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCategoryName() {
		return categoryName;
	}

	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}

	@Override
	public String toString() {
		return "ProductCategory [id=" + id + ", categoryName=" + categoryName + "]";
	}

    
}